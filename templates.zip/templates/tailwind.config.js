module.exports = {
    plugins: [
      require('@tailwindcss/typography'),
      // ...
    ]
  }